import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-seed-phrase',
  templateUrl: './login-seed-phrase.component.html',
  styleUrls: ['./login-seed-phrase.component.scss']
})
export class LoginSeedPhraseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
