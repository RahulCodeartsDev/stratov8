import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-step1',
  templateUrl: './info-step1.component.html',
  styleUrls: ['./info-step1.component.scss']
})
export class InfoStep1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
}
