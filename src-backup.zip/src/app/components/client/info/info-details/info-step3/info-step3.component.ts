import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-step3',
  templateUrl: './info-step3.component.html',
  styleUrls: ['./info-step3.component.scss']
})
export class InfoStep3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
