import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-details',
  templateUrl: './top-details.component.html',
  styleUrls: ['./top-details.component.scss']
})
export class TopDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
